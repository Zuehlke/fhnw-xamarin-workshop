﻿using System;
using MvvmCross.Binding.BindingContext;
using MvvmCross.Binding.iOS.Views;
using MvvmCross.iOS.Views;
using Mvx.Exercises.ViewModels;
using UIKit;

namespace Mvx.Exercises.iOS
{
	public partial class MainView : MvxViewController
	{
		int count = 1;

		public MainView (IntPtr handle) : base (handle)
		{
		}


		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
		    var bindingSet = this.CreateBindingSet<MainView, MainViewModel>();
		    bindingSet.Bind(Button.TitleLabel)
		        .To(vm => vm.BindingDemo);
            bindingSet.Apply();

		    // Perform any additional setup after loading the view, typically from a nib.
			Button.AccessibilityIdentifier = "myButton";
			Button.TouchUpInside += delegate {
				var title = string.Format ("{0} clicks!", count++);
				Button.SetTitle (title, UIControlState.Normal);
			};
         
		}

		public override void DidReceiveMemoryWarning ()
		{
			base.DidReceiveMemoryWarning ();
			// Release any cached data, images, etc that aren't in use.
		}
	}
}

