using Android.App;
using MvvmCross.Droid.Views;
using Mvx.Exercises.ViewModels;

namespace Mvx.Exercises.Droid.Views
{
    [Activity (Label = "Grades")]
    public class GradesActivity : MvxActivity<GradesViewModel>
    {
        protected override void OnViewModelSet()
        {
            base.OnViewModelSet();
            SetContentView(Resource.Layout.Grades);
        }
    }
}