﻿using MvvmCross.Core.ViewModels;
using MvvmCross.Platform.IoC;
using Mvx.Exercises.Services;

namespace Mvx.Exercises
{
    public class App : MvxApplication
    {
        public override void Initialize()
        {
            base.Initialize();
            //MvvmCross.Platform.Mvx.RegisterType<IMyService,MyService>();
          
            //CreatableTypes()
            //    .EndingWith("Repository")
            //    .AsInterfaces()
            //    .RegisterAsLazySingleton();

            //CreatableTypes()
            //    .EndingWith("Service")
            //    .AsInterfaces()
            //    .RegisterAsLazySingleton();

            //var serviceId = MvvmCross.Platform.Mvx.Resolve<IMyService>().Hello();
            //serviceId = MvvmCross.Platform.Mvx.Resolve<IMyService>().Hello();

            RegisterAppStart(new AppStart());
        }
    }
}