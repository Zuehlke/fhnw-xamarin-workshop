﻿using Mvx.Exercises.Models;

namespace Mvx.Exercises.Services
{
    internal class GradingService
    {
        public GradeResult GetResult(Grade grade)
        {
            if (grade.Achieved < 4)
                return GradeResult.CouldBeBetter;

            return grade.Achieved < 5 ? GradeResult.Good : GradeResult.Great;
        }
    }

    public enum GradeResult
    {
        CouldBeBetter,
        Good,
        Great
    }
}