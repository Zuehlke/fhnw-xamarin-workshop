﻿namespace Mvx.Exercises.Services
{
    public interface IMyService
    {
        int Hello();
    }

    public class MyService : IMyService
    {
        private static int ServiceCount;

        private int id;
        public MyService()
        {
            id = ++ServiceCount;
        }
        public int Hello()
        {
            return id;
        }
    }
}