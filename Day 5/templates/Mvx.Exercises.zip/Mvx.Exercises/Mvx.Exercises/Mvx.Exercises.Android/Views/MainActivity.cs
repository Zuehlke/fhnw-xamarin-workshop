using Android.App;
using MvvmCross.Droid.Views;
using Mvx.Exercises.ViewModels;

namespace Mvx.Exercises.Droid.Views
{
    [Activity(Label = "Mvvm with Mvx", MainLauncher = true)]
    public class MainActivity : MvxActivity<MainViewModel>
    {
        protected override void OnViewModelSet()
        {
            base.OnViewModelSet();
            SetContentView(Resource.Layout.Main);
        }
    }
}