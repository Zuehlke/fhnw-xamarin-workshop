﻿using System.Diagnostics;
using MvvmCross.Core.ViewModels;

namespace Mvx.Exercises.ViewModels
{
    public class MainViewModel : MvxViewModel
    {
        private string _bindingDemo;


        public string BindingDemo
        {
            get { return _bindingDemo; }
            set
            {
                _bindingDemo = value;
                RaisePropertyChanged();
            }
        }

        public MvxCommand ShowStudentsCommand
        {
            get { return new MvxCommand(() =>
            {
                Debug.WriteLine("TEST XXX");
                ShowViewModel<StudentViewModel>();
            }); }
        }
    }
}