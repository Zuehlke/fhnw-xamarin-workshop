﻿using System.Collections.ObjectModel;
using MvvmCross.Core.ViewModels;
using Mvx.Exercises.Models;
using Mvx.Exercises.Repositories;

namespace Mvx.Exercises.ViewModels
{
    public class StudentViewModel : MvxViewModel
    {
        private readonly IStudentRepository _studentRepository;
        private ObservableCollection<Course> _courses;

        private Student _currentStudent;

        public StudentViewModel(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public Student CurrentStudent
        {
            get { return _currentStudent; }
            set
            {
                _currentStudent = value;
                Courses = new MvxObservableCollection<Course>(_currentStudent.Courses);
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<Course> Courses
        {
            get { return _courses; }
            set
            {
                _courses = value;
                RaisePropertyChanged();
            }
        }

        public MvxCommand<Course> ShowGrades
        {
            get
            {
                return
                    new MvxCommand<Course>(
                        course =>
                        {
                            ShowViewModel<GradesViewModel>(new {studentId = CurrentStudent.Id, course = course.Id});
                        });
            }
        }

        protected override async void InitFromBundle(IMvxBundle parameters)
        {
            base.InitFromBundle(parameters);

            CurrentStudent = await _studentRepository.GetStudentById(2);
        }
    }
}