﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using MvvmCross.Core.ViewModels;
using Mvx.Exercises.Models;
using Mvx.Exercises.Repositories;

namespace Mvx.Exercises.ViewModels
{
    public class GradesViewModel : MvxViewModel
    {
        private decimal _achieved;
        private DateTime _examDate;
        private ObservableCollection<Grade> _grades;
        private Student _student;
        private readonly IStudentRepository _studentRepository;

        public GradesViewModel(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public Student Student
        {
            get { return _student; }
            set
            {
                _student = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<Grade> Grades
        {
            get { return _grades; }
            set
            {
                _grades = value;
                RaisePropertyChanged();
            }
        }

        public decimal Achieved
        {
            get { return _achieved; }
            set
            {
                _achieved = value;
                RaisePropertyChanged();
                RaisePropertyChanged(nameof(AddGrade));
            }
        }

        public DateTime ExamDate
        {
            get { return _examDate; }
            set
            {
                _examDate = value;
                RaisePropertyChanged();
                RaisePropertyChanged(nameof(AddGrade));
            }
        }

        public MvxCommand AddGrade
        {
            get
            {
                return new MvxCommand(() =>
                    {
                        _studentRepository.AddGrade(Student.Id, new Grade
                        {
                            Achieved = Achieved,
                            Course = CurrentCourse,
                            Date = ExamDate
                        });
                        LoadGrades(CurrentCourse.Id);
                    },
                    () => ExamDate > DateTime.MinValue && Math.Abs(Achieved) > 1 && Math.Abs(Achieved) < 6);
            }
        }

        public Course CurrentCourse { get; set; }

        public async void Init(int studentId, int course)
        {
            Student = await _studentRepository.GetStudentById(studentId);
            CurrentCourse = Student.Courses.FirstOrDefault(_ => _.Id == course);
            LoadGrades(course);
        }

        private void LoadGrades(int course)
        {
            var grades = Student.Grades.Where(_ => _.Course.Id == course);
            Grades = new MvxObservableCollection<Grade>(grades);
        }
    }
}