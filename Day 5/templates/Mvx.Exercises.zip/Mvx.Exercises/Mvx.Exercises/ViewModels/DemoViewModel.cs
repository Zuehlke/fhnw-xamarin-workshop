﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MvvmCross.Core.ViewModels;
using Mvx.Exercises.Services;

namespace Mvx.Exercises.ViewModels
{
    public class DemoViewModel : MvxViewModel
    {
        private readonly IMyService _service;

        public DemoViewModel(IMyService service)
        {
            _service = service;
        }
    }
}
